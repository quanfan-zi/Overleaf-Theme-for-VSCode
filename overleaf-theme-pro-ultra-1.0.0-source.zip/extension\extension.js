"use strict";

const vscode = require("vscode");

const BACKUP_KEY = "overleafThemeProUltra.typographyBackup.v1";

const TYPOGRAPHY_SETTINGS = {
  "editor.fontFamily": "'Lucida Console', 'Source Code Pro', monospace",
  "editor.fontSize": 20,
  "editor.lineHeight": 32,
  "editor.letterSpacing": 0,
  "editor.fontLigatures": false,
  "editor.tabSize": 4,
  "editor.fontWeight": "normal",
  "editor.cursorStyle": "line",
  "editor.cursorWidth": 1,
  "editor.wordWrap": "on"
};

function splitSettingId(settingId) {
  const dot = settingId.indexOf(".");
  if (dot === -1) {
    return ["", settingId];
  }
  return [settingId.slice(0, dot), settingId.slice(dot + 1)];
}

function getGlobalValue(settingId) {
  const inspected = vscode.workspace.getConfiguration().inspect(settingId);
  return inspected ? inspected.globalValue : undefined;
}

async function updateGlobalSetting(settingId, value) {
  const [section, name] = splitSettingId(settingId);
  await vscode.workspace
    .getConfiguration(section)
    .update(name, value, vscode.ConfigurationTarget.Global);
}

function captureBackup() {
  const backup = {};
  for (const settingId of Object.keys(TYPOGRAPHY_SETTINGS)) {
    const value = getGlobalValue(settingId);
    backup[settingId] = {
      exists: value !== undefined,
      value
    };
  }
  return backup;
}

async function applyTypography(context) {
  const existingBackup = context.globalState.get(BACKUP_KEY);
  if (!existingBackup) {
    await context.globalState.update(BACKUP_KEY, captureBackup());
  }

  for (const [settingId, value] of Object.entries(TYPOGRAPHY_SETTINGS)) {
    await updateGlobalSetting(settingId, value);
  }

  vscode.window.showInformationMessage("已应用 Overleaf 推荐排版。");
}

async function restoreTypography(context) {
  const backup = context.globalState.get(BACKUP_KEY);
  if (!backup) {
    vscode.window.showWarningMessage("没有找到可恢复的排版备份。请先运行“应用 Overleaf 推荐排版”。");
    return;
  }

  for (const settingId of Object.keys(TYPOGRAPHY_SETTINGS)) {
    const entry = backup[settingId] || { exists: false };
    await updateGlobalSetting(settingId, entry.exists ? entry.value : undefined);
  }

  await context.globalState.update(BACKUP_KEY, undefined);
  vscode.window.showInformationMessage("已恢复修改前排版。");
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand(
      "overleafThemeProUltra.applyTypography",
      () => applyTypography(context)
    ),
    vscode.commands.registerCommand(
      "overleafThemeProUltra.restoreTypography",
      () => restoreTypography(context)
    )
  );
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};
