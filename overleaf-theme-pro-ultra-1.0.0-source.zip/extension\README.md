# Overleaf Theme Pro Ultra

一个面向本地 LaTeX 写作的 VS Code 主题。目标不是简单套一层颜色，而是尽量复刻 Overleaf 编辑器的日常手感：浅色正文、蓝色文本命令、绿色数学内容、紫色数学命令、深色标签栏、Overleaf 风格选择区和更接近网页端的排版。

Overleaf Theme Pro Ultra is for LaTeX users who prefer local editing in VS Code but want the visual rhythm of Overleaf: calmer writing colors, Overleaf-like math highlighting, a darker editor chrome, and one-command typography setup.

## 功能

- 主题外观基于 Overleaf Theme，并按 Overleaf 编辑器习惯重新调整标签栏、路径栏、侧边栏、选择区、分隔线和编辑器颜色。
- LaTeX 高亮只保留本项目整理后的规则，避免旧主题通用 token 规则与自定义 LaTeX 规则混用。
- 内置一个轻量 TextMate 注入语法，用于补足 VS Code 默认 LaTeX 语法不容易识别的数学分隔符场景。
- 提供两条命令：
  - `Overleaf Theme Pro Ultra: 应用 Overleaf 推荐排版`
  - `Overleaf Theme Pro Ultra: 恢复修改前排版`

## 推荐排版

“应用 Overleaf 推荐排版”会写入以下全局 VS Code 设置，并在第一次应用时保存原值：

```json
{
  "editor.fontFamily": "'Lucida Console', 'Source Code Pro', monospace",
  "editor.fontSize": 20,
  "editor.lineHeight": 32,
  "editor.letterSpacing": 0,
  "editor.fontLigatures": false,
  "editor.tabSize": 4,
  "editor.fontWeight": "normal",
  "editor.cursorStyle": "line",
  "editor.cursorWidth": 1,
  "editor.wordWrap": "on"
}
```

“恢复修改前排版”会恢复命令保存的原值。恢复功能依赖本扩展命令第一次应用时保存的快照。

## 使用

### 安装 `.vsix`

图形界面安装：

1. 打开 VS Code 的 Extensions 视图。
2. 点击右上角 `...`。
3. 选择 `Install from VSIX...`。
4. 选择 `overleaf-theme-pro-ultra-1.0.0.vsix`。
5. 安装后按提示重载窗口。

命令行安装：

```bash
code --install-extension overleaf-theme-pro-ultra-1.0.0.vsix
```

### 启用主题

1. 按 `Ctrl+K Ctrl+T`，或运行 `Preferences: Color Theme`。
2. 选择 `Overleaf Theme Pro Ultra`。
3. 按 `Ctrl+Shift+P`，运行 `Overleaf Theme Pro Ultra: 应用 Overleaf 推荐排版`。

如果想撤回排版设置，运行 `Overleaf Theme Pro Ultra: 恢复修改前排版`。

## 设计边界

这个主题只使用 VS Code 官方主题、语法和命令能力；不注入自定义 CSS，不修改 VS Code 程序文件。因此它能稳定迁移，但也会受 VS Code 主题 API 限制。详细限制见 `02_KNOWN_LIMITATIONS.md`。

## 附加文档

- `01_COLOR_TABLE.md`：配色表。
- `02_KNOWN_LIMITATIONS.md`：已知限制。
- `03_CHANGELOG.md`：更新记录。
- `04_THIRD_PARTY_NOTICES.md`：原主题、Overleaf 和 VS Code 相关来源说明。
- `05_LICENSE.md`：许可证说明。
- `06_WORKSPACE.md`：源码包和继续开发说明。

## 来源与许可证

本项目来源和许可证说明见 `04_THIRD_PARTY_NOTICES.md` 与 `05_LICENSE.md`。
